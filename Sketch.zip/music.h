// Example: sound.tones(song);
